<!-- Quick View Modal Area -->
<div class="modal fade hide in" id="quickview1<?php echo e($product->id); ?>" data-backdrop="static" backdrop="static" keyboard="true" show="true" tabindex="-1" role="dialog" aria-labelledby="quickview1"
    aria-hidden="true" style="background: rgba(0, 0, 0, 0.5);z-index:999999999999999999;">
    <div class="modal-dialog modal-lg modal-dialog-centered " role="document">
        <div class="modal-content">
            <button type="button" class="close btn" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body">
                <div class="quickview_body">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 col-lg-5">
                                <div class="quickview_pro_img">
                                    <?php
                                        $photo=explode(',',$product->photo)
                                    ?>
                                    <img class="first_img" src="<?php echo e(asset($photo[0])); ?>" alt="<?php echo e($product->title); ?>">
                                    <!-- Product Badge -->
                                    <div class="product_badge">
                                        <span class="badge-new"><?php echo e($product->conditions); ?></span>
                                        <?php if($product->discount>0): ?>
                                            <span class="mt-2 badge-new"><?php echo e($product->discount); ?> %</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-7">
                                <div class="quickview_pro_des">
                                    <h4 class="title"><?php echo e(ucfirst($product->title)); ?></h4>
                                    <div class="top_seller_product_rating mb-15">
                                        <?php for($i=0;  $i<5;  $i++): ?>
                                            <?php if(round($product->reviews->avg('rate'))>$i): ?>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                            <?php else: ?>
                                                <i class="far fa-star" aria-hidden="true"></i>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <?php if($product->discount>0): ?>
                                        <h5 class="price">$ <?php echo e($product->offer_price); ?> <span>$ <?php echo e($product->price); ?></span></h5>
                                    <?php else: ?>
                                        <h5 class="price">$ <?php echo e($product->offer_price); ?></h5>
                                    <?php endif; ?>
                                    <p><?php echo html_entity_decode($product->summary); ?></p>
                                    <a href="<?php echo e(route('product.detail',$product->slug)); ?>">View Full Product Details</a>
                                </div>
                                <!-- Add to Cart Form -->
                                <form class="cart" method="post">
                                    <div class="quantity">
                                        <input data-id="<?php echo e($product->id); ?>" type="number" class="qty-text form-control" id="qty2" step="1" min="1" max="12"
                                            name="quantity" value="1">
                                    </div>
                                    <button type="submit" name="addtocart" data-product_id="<?php echo e($product->id); ?>" data-quantity="1" data-price="<?php echo e($product->offer_price); ?>" id="add_to_cart_button_details_<?php echo e($product->id); ?>" value="5"
                                        class="mt-1 ml-1 add_to_cart_button_details btn btn-primary mt-md-0 ml-md-3">Add to cart
                                    </button>
                                    <!-- Wishlist -->
                                    <div class="modal_pro_wishlist">
                                        <a href="javascript:void(0);" class="add_to_wishlist" data-quantity="1" data-id="<?php echo e($product->id); ?>"
                                            id="add_to_wishlist_<?php echo e($product->id); ?>"><i class="icofont-heart"></i></a>
                                    </div>
                                    <!-- Compare -->
                                    <div class="modal_pro_compare">
                                        <a href="compare.html"><i class="icofont-exchange"></i></a>
                                    </div>
                                </form>
                                <!-- Share -->
                                <div class="share_wf mt-30">
                                    <p>Share with friends</p>
                                    <div class="_icon">
                                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                        <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                        <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                        <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                        <a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Quick View Modal Area -->







    <!-- Quick View Modal Area shop -->
    
    <!-- Quick View Modal Area -->

    <!-- Quick View Modal Area detail product-->
    
    <!-- Quick View Modal Area -->



    <!-- Quick View Modal Area product category -->
    
    <!-- Quick View Modal Area -->
<script>
    .modal.fade{
        -webkit-transition:none;
        -moz-transition:none;
        -ms-transition:none;
        -o-transition:none;
        transition:none;

    }
</script>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/unuses/_modal.blade.php ENDPATH**/ ?>