<?php $__env->startSection('content'); ?>


    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-12">
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                    class="fa fa-arrow-left"></i></a> Order</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><i class="icon-home"></i></a>
                            </li>
                            <li class="breadcrumb-item">Views</li>
                            <li class="breadcrumb-item active">Order view</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Color Pickers -->
            <div class="clearfix row">
                <div class="col-md-12">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped ">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th style="width:60px;">#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Payment Methode</th>
                                            <th>Condition</th>
                                            <th>Order Status</th>
                                            <th>Amount</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($order->order_number); ?></td>
                                            <td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
                                            <td><?php echo e($order->email); ?></td>
                                            <td><?php echo e($order->payment_method == 'cod' ? 'Cash on Delivery' : $order->payment_method); ?>

                                            </td>
                                            <?php if($order->condition == 'pending'): ?>
                                                <td><span class="badge badge-info"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                            <?php elseif($order->condition=='processing'): ?>
                                                <td><span
                                                        class="badge badge-warning"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                            <?php elseif($order->condition=='delivered'): ?>
                                                <td><span
                                                        class="badge badge-primary"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                            <?php else: ?>
                                                <td><span
                                                        class="badge badge-danger"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                            <?php endif; ?>
                                            <?php if($order->payment_status == 'paid'): ?>
                                                <td><span
                                                        class="badge badge-success"><?php echo e(ucfirst($order->payment_status)); ?></span>
                                                </td>
                                            <?php else: ?>
                                                <td><span
                                                        class="badge badge-danger"><?php echo e(ucfirst($order->payment_status)); ?></span>
                                                </td>
                                            <?php endif; ?>
                                            <td><?php echo e(Helper::currency_converter($order->total_amount)); ?></td>
                                            <td style="text-align: center;">
                                                <div class="row">
                                                    <a href="<?php echo e(route('order.facture',$order->id)); ?>"
                                                        data-target="#userID<?php echo e($order->id); ?>" data-toggle="tooltip"
                                                        title="View facture"
                                                        class="float-left ml-1 btn btn-sm btn-outline-secondary"
                                                        data-placement="bottom"><i class="icon-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('order.pdf',$order->id)); ?>" title="Download facture"
                                                        class="float-left ml-1 btn btn-sm btn-outline-warning"
                                                        data-placement="bottom">
                                                        <i class="fa fa-download"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>


                            <div class="table-responsive">
                                <table class="table mt-4 table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th style="width:60px;">#</th>
                                            <th>Product Image</th>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <img src="<?php echo e($item->photo); ?>" style="max-width:100px;">
                                                </td>
                                                <td><?php echo e($item->title); ?></td>
                                                <td><?php echo e(Helper::currency_converter($item->offer_price)); ?></td>
                                                <td><?php echo e($item->pivot->quantity); ?></td>
                                                <td><?php echo e(Helper::currency_converter($item->offer_price * $item->pivot->quantity)); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <td colspan="6" class="text-center">No orders</td>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">

                            </div>
                            
                            <div class="border col-12 col-lg-5">
                                <div class="cart-total-area mb-30">
                                    <div class="table-responsive">
                                        <table class="table mb-3">
                                            <tbody>
                                                <tr>
                                                    <td>Sub Total</td>
                                                    <td><?php echo e(Helper::currency_converter($order->sub_total)); ?></td>
                                                </tr>
                                                <?php if($order->delivery_charge > 0): ?>
                                                    <tr>
                                                        <td>Delivery Charge</td>
                                                        <td><?php echo e(Helper::currency_converter($order->delivery_charge)); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                                <?php if($order->coupon > 0): ?>
                                                    <tr>
                                                        <td>Coupon</td>
                                                        <td><?php echo e(Helper::currency_converter($order->coupon)); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                                <tr>
                                                    <td>Total</td>
                                                    <td><?php echo e(Helper::currency_converter($order->sub_total)); ?></td>
                                                </tr>
                                            </tbody>
                                            <tbody>

                                                <form action="<?php echo e(route('order.status')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                                                    <tr>
                                                        <td><strong>Status</strong></td>
                                                        <td style="width: 30%">
                                                            <select name="condition" class="form-control" id="">
                                                                <option value="pending"
                                                                    <?php echo e($order->condition == 'delivered' || $order->condition == 'cancellation' ? 'disabled' : ''); ?>

                                                                    <?php echo e($order->condition == 'pending' ? 'selected' : ''); ?>>Pending
                                                                </option>
                                                                <option value="processing"
                                                                    <?php echo e($order->condition == 'delivered' || $order->condition == 'cancellation' ? 'disabled' : ''); ?>

                                                                    <?php echo e($order->condition == 'processing' ? 'selected' : ''); ?>>Processing
                                                                </option>
                                                                <option value="delivered"
                                                                    <?php echo e($order->condition == 'cancellation' ? 'disabled' : ''); ?>

                                                                    <?php echo e($order->condition == 'delivered' ? 'selected' : ''); ?>>Delivered
                                                                </option>
                                                                <option value="cancellation"
                                                                    <?php echo e($order->condition == 'delivered' ? 'disabled' : ''); ?>

                                                                    <?php echo e($order->condition == 'cancellation' ? 'selected' : ''); ?>>Cancellation
                                                                </option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><button class="mt-2 btn btn-sm btn-success">Valider</button>
                                                        </td>
                                                    </tr>
                                                </form>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
    <script>
        $('#lfm').filemanager('image');
    </script>

    <script>
        $(document).ready(function() {
            $('#description').summernote();
        });
    </script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('.dltBtn').click(function(e) {
            var form = $(this).closest('form');
            var dataID = $(this).data('id');
            e.preventDefault();
            swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this imaginary file",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                        swal("Poof! Your imaginary file has been deleted!", {
                            icon: "success"
                        });
                    } else {
                        swal("Your imaginary file is safe!");
                    }
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/backend/order/show.blade.php ENDPATH**/ ?>