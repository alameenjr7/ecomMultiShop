<nav class="navbar navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-btn">
            <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
        </div>

        <div class="navbar-brand">
            <a href="<?php echo e(route('admin')); ?>"><img src="<?php echo e(asset(get_setting('logo'))); ?>" alt="Kaay-Deals Logo"
                    class="img-responsive logo"></a>
        </div>

        <div class="navbar-right">
            

            <div id="navbar-menu">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="file-dashboard.html" class="icon-menu d-none d-sm-block d-md-none d-lg-block"><i
                                class="fa fa-folder-open-o"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('calendar')); ?>" class="icon-menu d-none d-sm-block d-md-none d-lg-block">
                            <i class="icon-calendar"></i>
                        </a>
                    </li>
                    <li>
                        <a href="app-chat.html" class="icon-menu d-none d-sm-block"><i class="icon-bubbles"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('messages')); ?>" class="icon-menu d-none d-sm-block"><i class="icon-envelope"></i><span
                                class="notification-dot"></span></a>
                    </li>
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown">
                            <i class="icon-bell"></i>
                            <span class="notification-dot"></span>
                        </a>
                        <ul class="dropdown-menu notifications">
                            <li class="header"><strong>You have 4 new Notifications</strong></li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <div class="media-left">
                                            <i class="icon-info text-warning"></i>
                                        </div>
                                        <div class="media-body">
                                            <p class="text">Campaign <strong>Holiday Sale</strong> is nearly reach
                                                budget limit.</p>
                                            <span class="timestamp">10:00 AM Today</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <div class="media-left">
                                            <i class="icon-like text-success"></i>
                                        </div>
                                        <div class="media-body">
                                            <p class="text">Your New Campaign <strong>Holiday Sale</strong> is approved.
                                            </p>
                                            <span class="timestamp">11:30 AM Today</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <div class="media-left">
                                            <i class="icon-pie-chart text-info"></i>
                                        </div>
                                        <div class="media-body">
                                            <p class="text">Website visits from Twitter is 27% higher than last week.
                                            </p>
                                            <span class="timestamp">04:00 PM Today</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <div class="media-left">
                                            <i class="icon-info text-danger"></i>
                                        </div>
                                        <div class="media-body">
                                            <p class="text">Error on website analytics configurations</p>
                                            <span class="timestamp">Yesterday</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="footer"><a href="javascript:void(0);" class="more">See all notifications</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown"><i
                                class="icon-equalizer"></i></a>
                        <ul class="dropdown-menu user-menu menu-icon">
                            <li class="menu-heading">ACCOUNT SETTINGS</li>
                            <li><a href="<?php echo e(route('settings')); ?>"><i class="icon-note"></i> <span>Settings</span></a></li>
                            <li><a href="<?php echo e(route('profile')); ?>"><i class="icon-equalizer"></i>
                                    <span>Profile</span></a></li>
                            <li class="menu-heading">BILLING</li>
                            <li><a href="<?php echo e(route('payment')); ?>"><i class="icon-credit-card"></i> <span>Payments Settings</span></a>
                            </li>
                            <li><a href="<?php echo e(route('smtp')); ?>"><i class="icon-printer"></i> <span>SMTP Settings</span></a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown currency-dropdown">
                        <?php
                            Helper::currency_load();
                            $currency_code=session('currency_code');
                            $currency_symbol=session('currency_symbol');
                            if($currency_symbol==""){
                                $system_default_currency_info=session('system_default_currency_info');
                                $currency_symbol=$system_default_currency_info->symbol;
                                $currency_code=$system_default_currency_info->code;
                            }
                        ?>
                        <a href="javascript:void(0);" class="dropdown-toggle btn-outline-dark" role="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown"><?php echo e($currency_symbol); ?> <?php echo e($currency_code); ?></a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
                            <?php $__currentLoopData = App\Models\Currency::where('status','active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" href="javascript:;" onclick="currency_change('<?php echo e($currency['code']); ?>')"><?php echo e($currency->symbol); ?> <?php echo e(Illuminate\Support\Str::upper($currency->code)); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <li>
                        
                        <a class="dropdown-item icon-menu"
                            href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"
                        >
                            <i class="icon-login"></i>
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/backend/layouts/nav.blade.php ENDPATH**/ ?>