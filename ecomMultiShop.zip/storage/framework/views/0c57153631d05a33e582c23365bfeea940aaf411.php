

<?php $__env->startSection('content'); ?>

<!-- Breadcumb Area -->
<div class="breadcumb_area">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <h5>Shop Grid</h5>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active"><?php echo e($categories->title); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- Breadcumb Area -->

<section class="shop_grid_area section_padding_100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Shop Top Sidebar -->
                <div class="flex-wrap shop_top_sidebar_area d-flex align-items-center justify-content-between">
                    <div class="view_area d-flex">
                        <div class="grid_view">
                            <a href="#" data-toggle="tooltip" data-placement="top" title="Grid View"><i class="icofont-layout"></i></a>
                        </div>
                        <div class="ml-3 list_view">
                            <a href="#" data-toggle="tooltip" data-placement="top" title="List View"><i class="icofont-listine-dots"></i></a>
                        </div>
                    </div>
                    <select id="sortBy" class="small right">
                        <option selected>Default</option>
                        <option value="priceAsc">Price - Lower To Higher</option>
                        <option value="priceDesc">Price - Higher To Lower</option>
                        <option value="titleAsc">Alphabetical Ascending</option>
                        <option value="titleDesc">Alphabetical Descending</option>
                        <option value="discAsc">Discount - Lower To Higher</option>
                        <option value="discDesc">Discount - Higher To Lower</option>
                    </select>
                </div>

                <div class="shop_grid_product_area">
                    <div class="row justify-content-center" id="product-data">
                        <!-- Single Product -->
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                                <?php echo $__env->make('frontend.layouts._single-product',['product'=>$product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="text-center ajax-load">
                    <img src="<?php echo e(asset('frontend/assets/img/loading.gif')); ?>" style="width: 5%">
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
    $('#sortBy').change(function(){
        var sort=$('#sortBy').val();

        window.location="<?php echo e(url(''.$route.'')); ?>/<?php echo e($categories->slug); ?>?sort="+sort;
    });
</script>


<script>
    function loadmoreData(page){
        $.ajax({
            url:'?page='+page,
            type:'get',
            beforeSend:function(){
                $('.ajax-load').show();
            }
        })
        .done(function(data){
            if(data.html==''){
                $('.ajax-load').html('No more product avialable');
                return;
            }
            $('.ajax-load').hide();
            $('#product-data').append(data.html);
        })
        .fail(function(){
            alert('Something went wrong! please try again');
        });
    }

    var page=1;
    $(window).scroll(function(){
        if($(window).scrollTop()+$(window).height()+120>=$(document).height()){
            page ++;
            loadmoreData(page);
        }
    });
</script>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/pages/product/product-category.blade.php ENDPATH**/ ?>