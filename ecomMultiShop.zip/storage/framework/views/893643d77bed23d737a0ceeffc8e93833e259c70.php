    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="<?php echo e(asset('frontend/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/default/classy-nav.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/default/scrollup.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery.countdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jarallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jarallax-video.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/default/active.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/bootstrap-notify.min.js')); ?>"></script>
    
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script>
        setTimeout(function(){
            $('#alert').slideUp();
        },4000);

    </script>

    <script>
        <?php if(Illuminate\Support\Facades\Session::has('success')): ?>
            $.notify("Success: <?php echo e(Illuminate\Support\Facades\Session::get('success')); ?>", {
                animate: {
                    enter: 'animated fadeInRight',
                    exit:'animated fadeOutRight',
                }
            });
        <?php endif; ?>
        <?php
            Illuminate\Support\Facades\Session::forget('success')
        ?>

        <?php if(Illuminate\Support\Facades\Session::has('error')): ?>
            $.notify("Sorry: <?php echo e(Illuminate\Support\Facades\Session::get('error')); ?>", {
                animate: {
                    enter: 'animated fadeInRight',
                    exit:'animated fadeOutRight',
                }
            });
        <?php endif; ?>
        <?php
            Illuminate\Support\Facades\Session::forget('error')
        ?>
    </script>

<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/layouts/script.blade.php ENDPATH**/ ?>