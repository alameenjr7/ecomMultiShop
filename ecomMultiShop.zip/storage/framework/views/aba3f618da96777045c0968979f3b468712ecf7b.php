<meta charset="UTF-8">
    <meta name="description" content="<?php echo e(get_setting('meta_description')); ?>">
    <meta name="keywords" content="<?php echo e(get_setting('meta_keywords')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title><?php echo e(get_setting('title')); ?></title>

    <!-- Favicon  -->
    <link rel="icon" href="<?php echo e(asset(get_setting('favicon'))); ?>">

    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/vendor/sweetalert/sweetalert.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/vendor/autocomplete/jquery-ui.css')); ?>css">

    <?php echo $__env->yieldContent('styles'); ?>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/layouts/head.blade.php ENDPATH**/ ?>