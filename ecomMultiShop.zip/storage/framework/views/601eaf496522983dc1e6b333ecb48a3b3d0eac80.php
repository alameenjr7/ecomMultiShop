<?php $__env->startSection('content'); ?>

<div id="main-content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
                            <i class="fa fa-arrow-left"></i>
                        </a>Users
                    </h2>
                    <ul class="float-left breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item">Order</li>
                        
                    </ul>
                    <p class="float-right"> Total Orders : <?php echo e($orders->count()); ?></p>
                </div>
            </div>
        </div>

        <div class="block-header">
            <div class="row">
                <div class="col-lg-12">
                    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>Order</strong> List</h2>
                        </div>
                        <div class="body">
                            
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped ">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th style="width:60px;">#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Payment Methode</th>
                                                <th>Condition</th>
                                                <th>Order Status</th>
                                                <th>Amount</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($order->order_number); ?></td>
                                                <td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
                                                <td><?php echo e($order->email); ?></td>
                                                <td><?php echo e($order->payment_method=="cod" ? "Cash on Delivery" : $order->payment_method); ?></td>
                                                <?php if($order->condition=='pending'): ?>
                                                <td><span class="badge badge-info"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                                <?php elseif($order->condition=='processing'): ?>
                                                <td><span
                                                        class="badge badge-warning"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                                <?php elseif($order->condition=='delivered'): ?>
                                                <td><span
                                                        class="badge badge-primary"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                                <?php else: ?>
                                                <td><span
                                                        class="badge badge-danger"><?php echo e(ucfirst($order->condition)); ?></span>
                                                </td>
                                                <?php endif; ?>
                                                <?php if($order->payment_status=='paid'): ?>
                                                <td><span
                                                        class="badge badge-success"><?php echo e(ucfirst($order->payment_status)); ?></span>
                                                </td>
                                                <?php else: ?>
                                                <td><span
                                                        class="badge badge-danger"><?php echo e(ucfirst($order->payment_status)); ?></span>
                                                </td>
                                                <?php endif; ?>
                                                <td><?php echo e(Helper::currency_converter($order->total_amount)); ?></td>
                                                <td style="text-align: center;">
                                                    <div class="row">
                                                        <a href="<?php echo e(route('order.show',$order->id)); ?>"
                                                            data-target="#userID<?php echo e($order->id); ?>" data-toggle="tooltip"
                                                            title="view"
                                                            class="float-left ml-1 btn btn-sm btn-outline-warning"
                                                            data-placement="bottom"><i class="icon-eye"></i>
                                                        </a>
                                                        <form class="float-left ml-1"
                                                            action="<?php echo e(route('order.destroy', $order->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('order.delete'); ?>
                                                            <a href="" data-toggle="tooltip" title="delete"
                                                                data-id="<?php echo e($order->id); ?>"
                                                                class="dltBtn btn btn-sm btn-outline-danger"
                                                                data-placement="bottom"><i class="icon-trash"></i></a>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <td colspan="8" class="text-center">No orders</td>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $('input[name=toogle]').change(function(){
        var mode = $(this).prop('checked');
        var id=$(this).val();
        // alert(id);
        $.ajax({
            url:"<?php echo e(route('user.status')); ?>",
            type:"POST",
            data:{
                _token:'<?php echo e(csrf_token()); ?>',
                mode:mode,
                id:id,
            },
            success:function(response){
                if(response.status){
                    alert(response.msg);
                }
                else{
                    alert('Please try again!')
                }
            }
        })
    });
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('.dltBtn').click(function(e) {
        var form = $(this).closest('form');
        var dataID = $(this).data('id');
        e.preventDefault();
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete)=>{
            if(willDelete){
                form.submit();
                swal("Poof! Your imaginary file has been deleted!", {
                    icon: "success"
                });
            } else {
                swal("Your imaginary file is safe!");
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/backend/order/index.blade.php ENDPATH**/ ?>