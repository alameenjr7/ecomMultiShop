

<?php $__env->startSection('content'); ?>

    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>Shop Grid</h5>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">Shop Grid</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

    <section class="shop_grid_area section_padding_100">
        <div class="container">
            <form action="<?php echo e(route('shop.filter')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 col-sm-5 col-md-4 col-lg-3">
                            <div class="shop_sidebar_area">
                                <?php if(count($cats)>0): ?>
                                    <!-- Single Widget -->
                                    <div class="widget catagory mb-30">
                                        <h6 class="widget-title">Product Categories</h6>
                                        <div class="widget-desc">
                                            <?php if(!empty($_GET['category'])): ?>
                                                <?php
                                                    $filter_cats=explode(',',$_GET['category']);
                                                ?>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <!-- Single Checkbox -->
                                                <div class="mb-2 custom-control custom-checkbox d-flex align-items-center">
                                                    <input type="checkbox"
                                                            <?php if(!empty($filter_cats) && in_array($cat->slug,$filter_cats)): ?>
                                                                checked
                                                            <?php endif; ?>
                                                        class="custom-control-input" id="<?php echo e($cat->slug); ?>" name="category[]" onchange="this.form.submit();" value="<?php echo e($cat->slug); ?>">
                                                    <label class="custom-control-label" for="<?php echo e($cat->slug); ?>"><?php echo e(ucfirst($cat->title)); ?><span class="text-muted">(<?php echo e(count($cat->products)); ?>)</span></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Single Widget -->
                                <div class="widget price mb-30">
                                    <h6 class="widget-title">Filter by Price</h6>
                                    <div class="widget-desc">
                                        <div class="slider-range">
                                            <div id="slider-range" data-min="<?php echo e(Helper::minPrice()); ?>" data-max="<?php echo e(Helper::maxPrice()); ?>" data-unit="$" class="slider-range-price ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" data-value-min="<?php echo e(Helper::minPrice()); ?>" data-value-max="<?php echo e(Helper::maxPrice()); ?>" data-label-result="Price:">
                                                <div class="ui-slider-range ui-widget-header ui-corner-all"></div>
                                                <span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
                                                <span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
                                            </div>
                                            <div class="mt-2 d-flex">
                                                <?php if(!empty($_GET['price'])): ?>
                                                    <?php
                                                        $price=explode('-',$_GET['price'])
                                                    ?>
                                                <?php endif; ?>
                                                <input type="hidden" id="price_range" value="<?php if(!empty($_GET['price'])): ?> <?php echo e($_GET['price']); ?> <?php endif; ?>" name="price_range">
                                                <input type="text" readonly id="amount" style="border: 0;width:70%;background-color: #f8f8ff;" value="$<?php if(!empty($_GET['price'])): ?><?php echo e($price['0']); ?><?php else: ?><?php echo e(Helper::minPrice()); ?><?php endif; ?>-$<?php if(!empty($_GET['price'])): ?><?php echo e($price['1']); ?><?php else: ?><?php echo e(Helper::maxPrice()); ?><?php endif; ?>">
                                                
                                                <button type="submit" class="float-right btn btn-sm btn-primary" style="margin: 12px 0px 12px 7px;height:30px;line-height:12px;">Filter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php if(count($brands)>0): ?>
                                    <!-- Single Widget -->
                                    <div class="widget brands mb-30">
                                        <h6 class="widget-title">Filter by brands</h6>
                                        <div class="widget-desc">
                                            <!-- Single Checkbox -->
                                            <?php if(!empty($_GET['brand'])): ?>
                                                <?php
                                                    $filter_brands=explode(',',$_GET['brand']);
                                                ?>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mb-2 custom-control custom-checkbox d-flex align-items-center">
                                                    <input type="checkbox"
                                                                <?php if(!empty($filter_brands) && in_array($brand->slug,$filter_brands)): ?>
                                                                    checked
                                                                <?php endif; ?>
                                                            class="custom-control-input" id="<?php echo e($brand->slug); ?>" name="brand[]" value="<?php echo e($brand->slug); ?>" onchange="this.form.submit();">
                                                    <label class="custom-control-label" for="<?php echo e($brand->slug); ?>"><?php echo e($brand->title); ?> <span class="text-muted">(<?php echo e(count($brand->products)); ?>)</span></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Single Widget -->
                                <div class="widget rating mb-30">
                                    <h6 class="widget-title">Average Rating</h6>
                                    <div class="widget-desc">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <span class="text-muted">(103)</span></a></li>

                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <span class="text-muted">(78)</span></a></li>

                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <span class="text-muted">(47)</span></a></li>

                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <span class="text-muted">(9)</span></a></li>

                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> <span class="text-muted">(3)</span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <!-- Single Widget -->
                                <div class="widget size mb-30">
                                    <h6 class="widget-title">Filter by Size</h6>
                                    <div class="widget-desc">
                                        <!-- Single Checkbox -->
                                        <div class="mb-2 custom-control custom-checkbox d-flex align-items-center">
                                            <input type="checkbox" class="custom-control-input" id="customCheck2" <?php if(!empty($_GET['size']) && $_GET['size'] =='S'): ?> checked <?php endif; ?> name="size" value="S" onchange="this.form.submit();">
                                            <label class="custom-control-label" for="customCheck2">Small <span class="text-muted">(<?php echo e(App\Models\Product::where(['status'=>'active','size'=>'S'])->count()); ?>)</span></label>
                                        </div>
                                        <!-- Single Checkbox -->
                                        <div class="mb-2 custom-control custom-checkbox d-flex align-items-center">
                                            <input type="checkbox" class="custom-control-input" id="customCheck12" <?php if(!empty($_GET['size']) && $_GET['size'] =='M'): ?> checked <?php endif; ?> name="size" value="M" onchange="this.form.submit();">
                                            <label class="custom-control-label" for="customCheck12">Medium <span class="text-muted">(<?php echo e(App\Models\Product::where(['status'=>'active','size'=>'M'])->count()); ?>)</span></label>
                                        </div>
                                        <!-- Single Checkbox -->
                                        <div class="mb-2 custom-control custom-checkbox d-flex align-items-center">
                                            <input type="checkbox" class="custom-control-input" id="customCheck22" <?php if(!empty($_GET['size']) && $_GET['size'] =='L'): ?> checked <?php endif; ?> name="size" value="L" onchange="this.form.submit();">
                                            <label class="custom-control-label" for="customCheck22">Large <span class="text-muted">(<?php echo e(App\Models\Product::where(['status'=>'active','size'=>'L'])->count()); ?>)</span></label>
                                        </div>
                                        <!-- Single Checkbox -->
                                        <div class="mb-2 custom-control custom-checkbox d-flex align-items-center">
                                            <input type="checkbox" class="custom-control-input" id="customCheck32" <?php if(!empty($_GET['size']) && $_GET['size'] =='XL'): ?> checked <?php endif; ?> name="size" value="XL" onchange="this.form.submit();">
                                            <label class="custom-control-label" for="customCheck32">Extra-Large <span class="text-muted">(<?php echo e(App\Models\Product::where(['status'=>'active','size'=>'XL'])->count()); ?>)</span></label>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                    </div>

                    <div class="col-12 col-sm-7 col-md-8 col-lg-9">
                        <!-- Shop Top Sidebar -->
                        <div class="flex-wrap shop_top_sidebar_area d-flex align-items-center justify-content-between">
                            <div class="view_area d-flex">
                                <div class="grid_view">
                                    <a href="shop-grid-left-sidebar.html" data-toggle="tooltip" data-placement="top" title="Grid View"><i class="icofont-layout"></i></a>
                                </div>
                                <div class="ml-3 list_view">
                                    <a href="shop-list-left-sidebar.html" data-toggle="tooltip" data-placement="top" title="List View"><i class="icofont-listine-dots"></i></a>
                                </div>
                            </div>
                            <select id="sortBy" name="sortBy" onchange="this.form.submit();" class="small right">
                                <option value=" ">Default</option>
                                <option value="priceAsc" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='priceAsc'): ?> selected <?php endif; ?>>Price - Lower To Higher</option>
                                <option value="priceDesc" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='priceDesc'): ?> selected <?php endif; ?>>Price - Higher To Lower</option>
                                <option value="titleAsc" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='titleAsc'): ?> selected <?php endif; ?>>Alphabetical Ascending</option>
                                <option value="titleDesc" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='titleDesc'): ?> selected <?php endif; ?>>Alphabetical Descending</option>
                                <option value="discAsc" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='discAsc'): ?> selected <?php endif; ?>>Discount - Lower To Higher</option>
                                <option value="discDesc" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='discDesc'): ?> selected <?php endif; ?>>Discount - Higher To Lower</option>
                            </select>
                        </div>

                        <div class="shop_grid_product_area" id="product-update">
                            <p class=""> Total Products : <?php echo e($products->total()); ?></p>
                            <div class="row justify-content-center">
                                <?php if(count($products)>0): ?>
                                    <!-- Single Product -->
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-9 col-sm-12 col-md-6 col-lg-4">
                                        <?php echo $__env->make('frontend.layouts._single-product',['product'=>$product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>No product found !</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Shop Pagination Area -->
                        <?php echo e($products->appends($_GET)->links('vendor.pagination.custom')); ?>


                    </div>
                </div>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function() {
        if($('#slider-range').length > 0){
            const max_value = parseInt($("#slider-range").data('max')) || 500;
            const min_value = parseInt($("#slider-range").data('min')) || 0;
            const currency = $("#slider-range").data('currency') || '';
            let price_range = min_value+'-'+max_value;

            if($("#price_range").length > 0 && $("#price_range").val()){
                price_range = $("#price_range").val().trim();
            }
            let price=price_range.split('-');

            $('#slider-range').slider({
                range:true,
                min:min_value,
                max:max_value,
                values:price,
                slide:function(event,ui){
                    $('#amount').val(ui.values[0]+"-"+ui.values[1]);
                    $('#price_range').val(ui.values[0]+"-"+ui.values[1]);
                }
            })
        }
    });
</script>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/pages/product/shop.blade.php ENDPATH**/ ?>