    <!-- Footer Area -->
    <footer class="footer_area section_padding_100_0">
        <div class="container">
            <div class="row">
                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md-5 col-lg-4 col-xl-3">
                    <div class="single_footer_area mb-100">
                        <div class="mb-4 footer_heading">
                            <h6>Contact Us</h6>
                        </div>
                        <ul class="footer_content">
                            <li><span>Address:</span> <?php echo e(App\Models\Setting::value('address')); ?></li>
                            <li><span>Phone:</span>+ <?php echo e(App\Models\Setting::value('phone')); ?></li>
                            <li><span>FAX:</span> <?php echo e(App\Models\Setting::value('fax')); ?></li>
                            <li><span>Email:</span> <?php echo e(App\Models\Setting::value('email')); ?></li>
                        </ul>
                        <div class="footer_social_area mt-15">
                            <a href="<?php echo e(App\Models\Setting::value('facebook_url')); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            <a href="<?php echo e(App\Models\Setting::value('twitter_url')); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            <a href="<?php echo e(App\Models\Setting::value('linkedin_url')); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            <a href="<?php echo e(App\Models\Setting::value('pinterest_url')); ?>"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                            <a href="<?php echo e(App\Models\Setting::value('instagram_url')); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                            <a href="<?php echo e(App\Models\Setting::value('snapchat_url')); ?>"><i class="fa fa-snapchat" aria-hidden="true"></i></a>
                            <a href="<?php echo e(App\Models\Setting::value('youtube_url')); ?>"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-100">
                        <div class="mb-4 footer_heading">
                            <h6>Account</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="<?php echo e(route('user.account')); ?>"><i class="icofont-rounded-right"></i> Account</a></li>
                            <li><a href="<?php echo e(route('user.order')); ?>"><i class="icofont-rounded-right"></i> Shop</a></li>
                            <li><a href="<?php echo e(route('blog.detail')); ?>"><i class="icofont-rounded-right"></i> Blog</a></li>
                            <li><a href="<?php echo e(route('contact.us')); ?>"><i class="icofont-rounded-right"></i> Contact</a></li>
                            <li><a href="<?php echo e(route('home')); ?>"><i class="icofont-rounded-right"></i> Home</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-100">
                        <div class="mb-4 footer_heading">
                            <h6>Information</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="#"><i class="icofont-rounded-right"></i> Terms &amp; Conditions</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Help</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Privacy Policy</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Delivary Info</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Return Policy</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md-5 col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-100">
                        <div class="mb-4 footer_heading">
                            <h6>Support</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="#"><i class="icofont-rounded-right"></i> Payment Method</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Product Support</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Affiliate Program</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Free Coupon</a></li>
                            <li><a href="#"><i class="icofont-rounded-right"></i> Free Shipping Policy</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-md-7 col-lg-8 col-xl-3">
                    <div class="single_footer_area mb-50">
                        <div class="mb-4 footer_heading">
                            <h6>Join our mailing list</h6>
                        </div>
                        <div class="subscribtion_form">
                            <form action="#" method="post">
                                <input type="email" name="mail" class="form-control mail" placeholder="Your E-mail Addrees">
                                <button type="submit" class="submit"><i class="icofont-long-arrow-right"></i></button>
                            </form>
                        </div>
                    </div>
                    <div class="single_footer_area mb-100">
                        <div class="mb-4 footer_heading">
                            <h6>Download our Mobile Apps</h6>
                        </div>
                        <div class="apps_download">
                            <a href="<?php echo e(App\Models\Setting::value('playStore_url')); ?>"><img src="<?php echo e(asset('frontend/assets/img/core-img/play-store.png')); ?>" alt="Play Store"></a>
                            <a href="<?php echo e(App\Models\Setting::value('appStore_url')); ?>"><img src="<?php echo e(asset('frontend/assets/img/core-img/app-store.png')); ?>" alt="Apple Store"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://ameentech.com/" target="_blank"><?php echo e(App\Models\Setting::value('footer')); ?></a></p>
                        </div>
                    </div>
                    <!-- Payment Method -->
                    <div class="col-12 col-md-6">
                        <div class="payment_method">
                            <img src="<?php echo e(asset('frontend/assets/img/payment-method/paypal.png')); ?>" alt="">
                            <img src="<?php echo e(asset('frontend/assets/img/payment-method/maestro.png')); ?>" alt="">
                            <img src="<?php echo e(asset('frontend/assets/img/payment-method/western-union.png')); ?>" alt="">
                            <img src="<?php echo e(asset('frontend/assets/img/payment-method/discover.png')); ?>" alt="">
                            <img src="<?php echo e(asset('frontend/assets/img/payment-method/american-express.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <script src="<?php echo e(asset('backend/assets/vendor/sweetalert/sweetalert.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>