

<?php $__env->startSection('content'); ?>

<div id="main-content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <h2>
                        <a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
                            <i class="fa fa-arrow-left"></i>
                        </a>
                            Users :
                        <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('user.create')); ?>">
                            <i class="icon-plus"></i>
                            Create User
                        </a>
                    </h2>
                    <ul class="float-left breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin')); ?>">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">User</li>
                    </ul>
                    <p class="float-right"> Total Users : <?php echo e($users->count()); ?></p>
                </div>
            </div>
        </div>

        <div class="block-header">
            <div class="row">
                <div class="col-lg-12">
                    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>User</strong> List</h2>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>S. N.</th>
                                            <th>Photo</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>S. N.</th>
                                            <th>Photo</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($loop->iteration); ?></th>
                                            <td style="text-align: center;">
                                                <img src="<?php echo e($item->photo ==null ? Helper::userDefaultImage() : asset($item->photo)); ?>" alt="user img" style="border-radius: 50%; height: 60px; width: 60px;" class="profile">
                                                
                                            </td>
                                            <td><?php echo e($item->full_name); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->phone); ?></td>
                                            <td style="text-align: center;"><?php echo e($item->address); ?></td>

                                            <td style="text-align: center;">
                                                <input type="checkbox" name="toogle" value="<?php echo e($item->id); ?>"
                                                    data-toggle="switchbutton" <?php echo e($item->status=='active' ? 'checked' :
                                                ''); ?>

                                                data-onlabel="active" data-offlabel="inactive" data-size="sm"
                                                data-onstyle="success" data-offstyle="danger">
                                            </td>
                                            <td style="text-align: center;">
                                                <div class="row">
                                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#userID<?php echo e($item->id); ?>" data-toggle="tooltip"
                                                        title="view" class="float-left ml-1 btn btn-sm btn-outline-secondary"
                                                        data-placement="bottom"><i class="icon-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('user.edit', $item->id)); ?>" data-toggle="tooltip"
                                                        title="edit" class="float-left ml-1 btn btn-sm btn-outline-warning"
                                                        data-placement="bottom"><i class="icon-note"></i></a>
                                                    <form class="float-left ml-1"
                                                        action="<?php echo e(route('user.destroy', $item->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <a href="" data-toggle="tooltip" title="delete"
                                                            data-id="<?php echo e($item->id); ?>"
                                                            class="dltBtn btn btn-sm btn-outline-danger"
                                                            data-placement="bottom"><i class="icon-trash"></i></a>
                                                    </form>
                                                </div>
                                            </td>
                                            
                                            <!-- Modal -->
                                            <div class="modal fade" id="userID<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <?php
                                                        $user=\App\Models\User::where('id',$item->id)->first();
                                                    ?>
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="text-center">
                                                            <img src="<?php echo e($user->photo); ?>" style="height: 70px; width: 70px; border-radius: 50%; margin: 2% 0" alt="">

                                                            <div class="text-center">
                                                                
                                                                <p><strong><?php echo e($user->username); ?></strong></p>
                                                            </div>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <strong>Full Name:</strong>
                                                                    <p><?php echo e($user->full_name); ?></p>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <strong>Email:</strong>
                                                                    <p><?php echo e($user->email); ?></p>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <strong>Phone N.:</strong>
                                                                    <p><?php echo e($user->phone); ?></p>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <strong>Address:</strong>
                                                                    <p><?php echo e($user->address); ?></p>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <strong>Role:</strong>
                                                                    <?php if($user->role=='admin'): ?>
                                                                        <p class="badge badge-success"><?php echo e($user->role); ?></p>
                                                                    <?php elseif($user->role=='vendor'): ?>
                                                                        <p class="badge badge-warning"><?php echo e($user->role); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="badge badge-primary"><?php echo e($user->role); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <strong>Status:</strong>
                                                                    <?php if($user->status=='active'): ?>
                                                                        <p class="badge badge-success"><?php echo e($user->status); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="badge badge-danger"><?php echo e($user->status); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="button" class="btn btn-primary" data-dismiss="modal">Save Change</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<script>
    $('input[name=toogle]').change(function(){
        var mode = $(this).prop('checked');
        var id=$(this).val();
        // alert(id);
        $.ajax({
            url:"<?php echo e(route('user.status')); ?>",
            type:"POST",
            data:{
                _token:'<?php echo e(csrf_token()); ?>',
                mode:mode,
                id:id,
            },
            success:function(response){
                if(response.status){
                    alert(response.msg);
                }
                else{
                    alert('Please try again!')
                }
            }
        })
    });
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('.dltBtn').click(function(e) {
        var form = $(this).closest('form');
        var dataID = $(this).data('id');
        e.preventDefault();
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete)=>{
            if(willDelete){
                form.submit();
                swal("Poof! Your imaginary file has been deleted!", {
                    icon: "success"
                });
            } else {
                swal("Your imaginary file is safe!");
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/backend/user/index.blade.php ENDPATH**/ ?>