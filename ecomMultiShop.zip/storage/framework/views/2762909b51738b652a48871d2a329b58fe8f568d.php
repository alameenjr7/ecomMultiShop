<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('backend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="theme-cyan">

    <!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img src="<?php echo e(asset(get_setting('logo'))); ?>" width="48" height="48" alt="Kaay-Deals"></div>
        <p>Please wait...</p>
    </div>
</div>
<!-- Overlay For Sidebars -->

<div id="wrapper">

   <?php echo $__env->make('backend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->yieldContent('content'); ?>

</div>
    <?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <script>
        function currency_change(currency_code){
            $.ajax({
                type:'POST',
                url:'<?php echo e(route('currency.load')); ?>',
                data:{
                    currency_code:currency_code,
                    _token:'<?php echo e(csrf_token()); ?>',
                },
                success:function(response){
                    if(response['status']){
                        location.reload();
                    }
                    else{
                        alert('server error');
                    }
                }
            });
        }
    </script>
    

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>