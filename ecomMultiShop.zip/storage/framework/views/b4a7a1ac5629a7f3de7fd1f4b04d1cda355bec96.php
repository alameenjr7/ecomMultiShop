<div class="col-12">
    <div class="cart-table">
        <div class="table-responsive">
            <table class="table table-bordered mb-30">
                <thead>
                    <tr>
                        <th scope="col"><i class="icofont-ui-delete"></i></th>
                        <th scope="col">Image</th>
                        <th scope="col">Product</th>
                        <th scope="col">Unit Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = \Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <i class="icofont-close cart_delete" data-id="<?php echo e($item->rowId); ?>"></i>
                            </th>
                            <td>
                                <img src="<?php echo e($item->model->photo); ?>" alt="Product">
                            </td>
                            <td>
                                <a href="<?php echo e(route('product.detail',$item->model->slug)); ?>"><?php echo e($item->name); ?></a>
                            </td>
                            <td><?php echo e(Helper::currency_converter($item->price)); ?></td>
                            <td>
                                <div class="quantity">
                                    <input type="number" data-id="<?php echo e($item->rowId); ?>" class="qty-text" id="qty-input-<?php echo e($item->rowId); ?>" step="1" min="1" max="10" name="quantity" value="<?php echo e($item->qty); ?>">
                                    <input type="hidden" data-id="<?php echo e($item->rowId); ?>" data-product-quantity="<?php echo e($item->model->stock); ?>" id="update-cart-<?php echo e($item->rowId); ?>">
                                </div>
                            </td>
                            <td><?php echo e(Helper::currency_converter($item->subtotal())); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-12 col-lg-6">
    <div class="cart-apply-coupon mb-30">
        <h6>Have a Coupon?</h6>
        <p>Enter your coupon code here &amp; get awesome discounts!</p>
        <!-- Form -->
        <div class="coupon-form">
            <form action="<?php echo e(route('coupon.add')); ?>" id="coupon-form" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control" name="code" placeholder="Enter Your Coupon Code">
                <button type="submit" class="coupon-btn btn btn-primary">Apply Coupon</button>
            </form>
        </div>
    </div>
</div>

<div class="col-12 col-lg-5">
    <div class="cart-total-area mb-30">
        <h5 class="mb-3">Cart Totals</h5>
        <div class="table-responsive">
            <table class="table mb-3">
                <tbody>
                    <tr>
                        <td>Sub Total</td>
                        <td><?php echo e(Helper::currency_converter(\Gloudemans\Shoppingcart\Facades\Cart::subtotal())); ?></td>
                    </tr>
                    <?php if(\Illuminate\Support\Facades\Session::has('coupon')): ?>
                        <tr>
                            <td>Save Amount</td>
                            <td><?php echo e(Helper::currency_converter(\Illuminate\Support\Facades\Session::get('coupon')['value'])); ?>


                            </td>
                        </tr>
                    <?php endif; ?>
                    
                    <?php if(\Illuminate\Support\Facades\Session::has('coupon')): ?>
                        <tr>
                            <td>Total</td>
                                <td><?php echo e(Helper::currency_converter(
                                    (float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal())-\Illuminate\Support\Facades\Session::get('coupon')['value']
                                )); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <a href="<?php echo e(route('checkout1')); ?>" class="btn btn-primary d-block">Proceed To Checkout</a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/layouts/_cart-list.blade.php ENDPATH**/ ?>