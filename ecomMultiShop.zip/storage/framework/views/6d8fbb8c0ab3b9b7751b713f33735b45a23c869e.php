

<?php $__env->startSection('content'); ?>


<div id="main-content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-12">
                    <h2>
                        <a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
                            <i class="fa fa-arrow-left"></i>
                        </a>SMTP Setting
                    </h2>
                </div>
            </div>
        </div>

        <!-- Color Pickers -->
        <div class="clearfix row">

            <div class="col-md-12">
                <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="body">
                        <form action="<?php echo e(route('smtp.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="clearfix row">
                                <div class="col-12">
									<div class="col-12">
										<div class="row form-group">
											<input type="hidden" name="types[]" value="MAIL_DRIVER">
											<div class="col-3">
												<label for="">TYPE</label>
											</div>
											<div class="col-9">
												<select name="MAIL_DRIVER" id="" class="form-control" onchange="checkMailDriver();">
													<option value="sendmail" <?php if(env('MAIL_DRIVER')=='sendmail'): ?> selected <?php endif; ?>>SendMail</option>
													<option value="smtp" <?php if(env('MAIL_DRIVER')=='smtp'): ?> selected <?php endif; ?>>SMTP</option>
													<option value="mailgun" <?php if(env('MAIL_DRIVER')=='mailgun'): ?> selected <?php endif; ?>>Mailgun</option>
												</select>
											</div>
										</div>
									</div>
								</div>

								
								<div id="smtp" class="col-12 mt-3">
									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAIL_HOST">
											<div class="col-3">
												<label for="">MAIL HOST</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAIL_HOST" value="<?php echo e(env('MAIL_HOST')); ?>">
											</div>
										</div>
									</div>
									
									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAIL_PORT">
											<div class="col-3">
												<label for="">MAIL PORT</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAIL_PORT" value="<?php echo e(env('MAIL_PORT')); ?>">
											</div>
										</div>
									</div>
									
									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAIL_ENCRYPTION">
											<div class="col-3">
												<label for="">MAIL ENCRYPTION</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAIL_ENCRYPTION" value="<?php echo e(env('MAIL_ENCRYPTION')); ?>">
											</div>
										</div>
									</div>

									
									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAIL_USERNAME">
											<div class="col-3">
												<label for="">MAIL USERNAME</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAIL_USERNAME" value="<?php echo e(env('MAIL_USERNAME')); ?>">
											</div>
										</div>
									</div>

									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAIL_PASSWORD">
											<div class="col-3">
												<label for="">MAIL PASSWORD</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAIL_PASSWORD" value="<?php echo e(env('MAIL_PASSWORD')); ?>">
											</div>
										</div>
									</div>

									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAIL_FROM_ADDRESS">
											<div class="col-3">
												<label for="">MAIL FROM ADDRESS</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAIL_FROM_ADDRESS" value="<?php echo e(env('MAIL_FROM_ADDRESS')); ?>">
											</div>
										</div>
									</div>

									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAIL_FROM_NAME">
											<div class="col-3">
												<label for="">MAIL FROM NAME</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAIL_FROM_NAME" value="<?php echo e(env('MAIL_FROM_NAME')); ?>">
											</div>
										</div>
									</div>
								</div>

								
								<div id="mailgun" class="col-12 mt-3">
									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAILGUN_DOMAIN">
											<div class="col-3">
												<label for="">MAILGUN DOMAIN</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAILGUN_DOMAIN" value="<?php echo e(env('MAILGUN_DOMAIN')); ?>">
											</div>
										</div>
									</div>
									<div class="col-12 mt-3">
										<div class="form-group row">
											<input type="hidden" name="types[]" value="MAILGUN_SECRET">
											<div class="col-3">
												<label for="">MAILGUN SECRET</label>
											</div>
											<div class="col-9">
												<input type="text" class="form-control" name="MAILGUN_SECRET" value="<?php echo e(env('MAILGUN_SECRET')); ?>">
											</div>
										</div>
									</div>
								</div>
                            </div>
                            <button type="submit" class="btn btn-success mt-3">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>

<script>
    $(document).ready(function () {
		checkMailDriver();
	});

	function checkMailDriver(){
		if($('select[name=MAIL_DRIVER]').val()=='mailgun'){
			$('#mailgun').show();
			$('#smtp').hide();
		}
		else{
			$('#mailgun').hide();
			$('#smtp').show();
		}
	}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/backend/settings/smtp.blade.php ENDPATH**/ ?>