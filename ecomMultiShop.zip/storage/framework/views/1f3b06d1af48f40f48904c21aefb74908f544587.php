

<?php $__env->startSection('content'); ?>

<!-- Breadcumb Area -->
<div class="breadcumb_area">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <h5>Checkout</h5>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Checkout</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- Breadcumb Area -->

<div class="checkout_steps_area">
    <a class="complated" href="<?php echo e(route('checkout1')); ?>"><i class="icofont-check-circled"></i> Billing</a>
    <a class="complated" href="<?php echo e(route('checkout2')); ?>"><i class="icofont-check-circled"></i> Shipping</a>
    <a class="active" href="<?php echo e(route('checkout3')); ?>"><i class="icofont-check-circled"></i> Payment</a>
    <a href="<?php echo e(route('checkout4')); ?>"><i class="icofont-check-circled"></i> Review</a>
</div>

<!-- Checkout Area -->
<div class="checkout_area section_padding_100">
    <div class="container">
        <form action="<?php echo e(route('checkout3.store')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col-12">
                    <div class="clearfix checkout_details_area">
                        <div class="payment_method">
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                <!-- Single Payment Method -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="five">
                                        <h6 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse"
                                                data-parent="#accordion" href="#collapse_five" aria-expanded="false"
                                                aria-controls="collapse_five"><i
                                                    class="icofont-cash-on-delivery-alt"></i> Cash on Delivery
                                            </a>
                                        </h6>
                                    </div>
                                    <div aria-expanded="false" id="collapse_five" class="panel-collapse collapse show"
                                        role="tabpanel" aria-labelledby="five">
                                        <div class="panel-body">
                                            <div class="custom-control custom-checkbox">
                                                <input type="radio" required name="payment_method" value="cod" class="custom-control-input" id="customCheck2">
                                                <label class="custom-control-label" for="customCheck2">Cash on
                                                    Delivery</label>
                                            </div>
                                            <p>Please send your cheque to Store Name, Store Street, Store Town, Store
                                                State / County, Store Postcode.</p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Single Payment Method -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="five">
                                        <h6 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse"
                                                data-parent="#accordion" href="#collapse_five" aria-expanded="false"
                                                aria-controls="collapse_five"><i
                                                    class="icofont-paypal-alt"></i> Pay with PayPal
                                            </a>
                                        </h6>
                                    </div>
                                    <div aria-expanded="false" id="collapse_five" class="panel-collapse collapse show"
                                        role="tabpanel" aria-labelledby="five">
                                        <div class="panel-body">
                                            <div class="custom-control custom-checkbox">
                                                <input type="radio" required name="payment_method" value="paypal" class="custom-control-input" id="customCheck3">
                                                <label class="custom-control-label" for="customCheck3">Pay with
                                                    PayPal</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Single Payment Method -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="five">
                                        <h6 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse"
                                                data-parent="#accordion" href="#collapse_five" aria-expanded="false"
                                                aria-controls="collapse_five"><i
                                                    class="icofont-razor"></i> Pay with Razor
                                            </a>
                                        </h6>
                                    </div>
                                    <div aria-expanded="false" id="collapse_five" class="panel-collapse collapse show"
                                        role="tabpanel" aria-labelledby="five">
                                        <div class="panel-body">
                                            <div class="custom-control custom-checkbox">
                                                <input type="radio" required name="payment_method" value="razor" class="custom-control-input" id="customCheck4">
                                                <label class="custom-control-label" for="customCheck4">Pay with
                                                    Razor</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Single Payment Method -->
                                

                                <!-- Single Payment Method -->
                                

                                <!-- Single Payment Method -->
                                

                                <!-- Single Payment Method -->
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="checkout_pagination d-flex justify-content-end mt-30">
                        <a href="<?php echo e(route('checkout2')); ?>" class="mt-2 ml-2 btn btn-primary">Go Back</a>
                        <button type="submit" class="mt-2 ml-2 btn btn-primary">Final Step</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Checkout Area End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/pages/checkout/checkout3.blade.php ENDPATH**/ ?>