<?php $__env->startSection('content'); ?>

<div id="main-content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <h2>
                        <a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
                            <i class="fa fa-arrow-left"></i>
                        </a>Products : <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('product.create')); ?>">
                            <i class="icon-plus"></i> Create Product
                        </a>
                    </h2>
                    <ul class="float-left breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin')); ?>">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">Product</li>
                    </ul>
                    <p class="float-right"> Total Products : <?php echo e($products->count()); ?></p>
                </div>
            </div>
        </div>

        <div class="block-header">
            <div class="row">
                <div class="col-lg-12">
                    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>Product</strong> List</h2>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>S. N.</th>
                                            <th>Title</th>
                                            <th>Photo</th>
                                            <th>Price</th>
                                            <th>Discount</th>
                                            <th>Offer Price</th>
                                            <th>Conditions</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>S. N.</th>
                                            <th>Title</th>
                                            <th>Photo</th>
                                            <th>Price</th>
                                            <th>Discount</th>
                                            <th>Offer Price</th>
                                            <th>Conditions</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $photo=explode(',',$item->photo);
                                            ?>
                                        <tr>
                                            <th><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($item->title); ?></td>
                                            <td style="text-align: center">
                                                <img src="<?php echo e($photo[0] ==null ? Helper::backDefaultImage() : asset($item->photo)); ?>" alt="banner img" style="height: 60px; width: 60px;">
                                            </td>
                                            <td><?php echo e(Helper::currency_converter($item->price)); ?></td>
                                            <td style="text-align: center"><?php echo e($item->discount); ?> %</td>
                                            <td><?php echo e(Helper::currency_converter($item->offer_price)); ?></td>
                                            <td style="text-align: center">
                                                <?php if($item->conditions == 'new'): ?>
                                                    <span class="badge badge-success">
                                                        <?php echo e($item->conditions); ?>

                                                    </span>
                                                <?php elseif($item->conditions == 'popular'): ?>
                                                    <span class="badge badge-warning">
                                                        <?php echo e($item->conditions); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge badge-primary">
                                                        <?php echo e($item->conditions); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <input type="checkbox" name="toogle" value="<?php echo e($item->id); ?>"
                                                    data-toggle="switchbutton" <?php echo e($item->status=='active' ? 'checked' :
                                                ''); ?>

                                                data-onlabel="active" data-offlabel="inactive" data-size="sm"
                                                data-onstyle="success" data-offstyle="danger">
                                            </td>
                                            <td style="text-align: center">
                                                <a href="<?php echo e(route('product.show',$item->id)); ?>"  data-toggle="tooltip"
                                                    title="add_attribute" class="float-left btn btn-sm btn-outline-primary"
                                                    data-placement="bottom"><i class="icon-plus"></i>
                                                </a>
                                                <a href="javascript:void(0);" data-toggle="modal" data-target="#productID<?php echo e($item->id); ?>" data-toggle="tooltip"
                                                    title="view" class="float-left ml-1 btn btn-sm btn-outline-info"
                                                    data-placement="bottom"><i class="icon-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('product.edit',$item->id)); ?>" data-toggle="tooltip"
                                                    title="edit" class="float-left ml-1 btn btn-sm btn-outline-warning"
                                                    data-placement="bottom"><i class="icon-note"></i>
                                                </a>
                                                <form class="float-left ml-1"
                                                    action="<?php echo e(route('product.destroy',$item->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <a href="" data-toggle="tooltip" title="delete"
                                                        data-id="<?php echo e($item->id); ?>"
                                                        class="dltBtn btn btn-sm btn-outline-danger"
                                                        data-placement="bottom"><i class="icon-trash"></i></a>
                                                </form>
                                            </td>
                                            
                                            <!-- Modal -->
                                            <div class="modal fade" id="productID<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <?php
                                                        $product=\App\Models\Product::where('id',$item->id)->first();
                                                    ?>
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(\Illuminate\Support\Str::upper($product->title)); ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <strong>Summary:</strong>
                                                            <p><?php echo html_entity_decode($product->summary); ?></p>

                                                            <strong>Description:</strong>
                                                            <p><?php echo html_entity_decode($product->description); ?></p>

                                                            <div class="row">
                                                                <div class="col-md-4">
                                                                    <strong>Price:</strong>
                                                                    <p><?php echo e(Helper::currency_converter($product->price)); ?></p>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <strong>Offer Price:</strong>
                                                                    <p><?php echo e(Helper::currency_converter($product->offer_price)); ?></p>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <strong>Stock:</strong>
                                                                    <?php if($product->stock>=100): ?>
                                                                        <p class="badge badge-success"><?php echo e($product->stock); ?></p>
                                                                    <?php elseif($product->stock<=100 && $product->stock>=30): ?>
                                                                        <p class="badge badge-warning"><?php echo e($product->stock); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="badge badge-danger"><?php echo e($product->stock); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-md-4">
                                                                    <strong>Brand:</strong>
                                                                    <p><?php echo e(\App\Models\Brand::where('id',$product->brand_id)->value('title')); ?></p>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <strong>Category:</strong>
                                                                    <p><?php echo e(\App\Models\Category::where('id',$product->cat_id)->value('title')); ?></p>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <strong>Child Category:</strong>
                                                                    <p><?php echo e(\App\Models\Category::where('id',$product->child_cat_id)->value('title')); ?></p>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-md-4">
                                                                    <strong>Discount:</strong>
                                                                    <?php if($product->discount>=70 && $product->discount=100): ?>
                                                                        <p class="badge badge-success"><?php echo e($product->discount); ?></p>
                                                                    <?php elseif($product->discount>20 && $product->stock<70): ?>
                                                                        <p class="badge badge-warning"><?php echo e($product->discount); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="badge badge-danger"><?php echo e($product->discount); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <strong>Size:</strong>
                                                                    <?php if($product->size=='S'): ?>
                                                                        <p class="badge badge-success"><?php echo e($product->size); ?></p>
                                                                    <?php elseif($product->size=='M'): ?>
                                                                        <p class="badge badge-warning"><?php echo e($product->size); ?></p>
                                                                    <?php elseif($product->size=='L'): ?>
                                                                        <p class="badge badge-primary"><?php echo e($product->size); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="badge badge-secondary"><?php echo e($product->size); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <strong>Vendor:</strong>
                                                                    <p class="badge badge-info"><?php echo e(\App\Models\User::where('id',$product->vendor_id)->value('full_name')); ?></p>
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <strong>Condition:</strong>
                                                                    <?php if($product->conditions=='new'): ?>
                                                                        <p class="badge badge-success"><?php echo e($product->conditions); ?></p>
                                                                    <?php elseif($product->conditions=='popular'): ?>
                                                                        <p class="badge badge-warning"><?php echo e($product->conditions); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="badge badge-primary"><?php echo e($product->conditions); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <strong>Status:</strong>
                                                                    <?php if($product->status=='active'): ?>
                                                                        <p class="badge badge-success"><?php echo e($product->status); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="badge badge-danger"><?php echo e($product->status); ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $('input[name=toogle]').change(function(){
        var mode = $(this).prop('checked');
        var id=$(this).val();
        // alert(id);
        $.ajax({
            url:"<?php echo e(route('product.status')); ?>",
            type:"POST",
            data:{
                _token:'<?php echo e(csrf_token()); ?>',
                mode:mode,
                id:id,
            },
            success:function(response){
                if(response.status){
                    alert(response.msg);
                }
                else{
                    alert('Please try again!')
                }
            }
        })
    });
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('.dltBtn').click(function(e) {
        var form = $(this).closest('form');
        var dataID = $(this).data('id');
        e.preventDefault();
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete)=>{
            if(willDelete){
                form.submit();
                swal("Poof! Your imaginary file has been deleted!", {
                    icon: "success"
                });
            } else {
                swal("Your imaginary file is safe!");
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/backend/product/index.blade.php ENDPATH**/ ?>