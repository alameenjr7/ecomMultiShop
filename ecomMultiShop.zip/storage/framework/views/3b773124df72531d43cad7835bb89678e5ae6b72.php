

<?php $__env->startSection('content'); ?>

<!-- Breadcumb Area -->
<div class="breadcumb_area">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <h5>Checkout</h5>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Checkout</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- Breadcumb Area -->

<!-- Checkout Step Area -->
<div class="checkout_steps_area">
    
    <a class="active" href="<?php echo e(route('checkout1')); ?>"><i class="icofont-check-circled"></i> Billing</a>
    <a href="<?php echo e(route('checkout2')); ?>"><i class="icofont-check-circled"></i> Shipping</a>
    <a href="<?php echo e(route('checkout3')); ?>"><i class="icofont-check-circled"></i> Payment</a>
    <a href="<?php echo e(route('checkout4',$user->id)); ?>"><i class="icofont-check-circled"></i> Review</a>
</div>

<!-- Checkout Area -->
<div class="checkout_area section_padding_100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if($errors->any): ?>
                    <div class="alert alert-danger" id="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <form action="<?php echo e(route('checkout1.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-12">
                    <div class="clearfix checkout_details_area">
                        <h5 class="mb-4">Billing Details</h5>
                        <div class="row">
                            <?php
                            $name=explode(' ',$user->full_name)
                            ?>
                            <div class="mb-3 col-md-6">
                                <label for="first_name">First Name</label>
                                <input type="text" class="form-control" id="first_name" name="first_name"
                                    placeholder="First Name" value="<?php echo e($name[0]); ?>" required>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="last_name">Last Name</label>
                                <input type="text" class="form-control" id="last_name" name="last_name"
                                    placeholder="Last Name" value="<?php echo e($name[1]); ?>" required>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="email_address">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    placeholder="Email Address" value="<?php echo e($user->email); ?>" readonly>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="phone_number">Phone Number</label>
                                <input type="number" class="form-control" id="phone" name="phone" min="9"
                                    value="<?php echo e($user->phone); ?>" placeholder="221 772050626">
                            </div>
                            <div class="mb-3 col-md-12">
                                <label for="country">Country</label>
                                <input type="text" class="form-control" id="country" name="country"
                                    value="<?php echo e($user->country); ?>" placeholder="ex. Sénégal">
                            </div>
                            <div class="mb-3 col-md-12">
                                <label for="street_address">Street address</label>
                                <input type="text" class="form-control" id="address" name="address"
                                    placeholder="Street Address" value="<?php echo e($user->address); ?>">
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="apartment_suite">Apartment/Suite/Unit</label>
                                <input type="text" class="form-control" id="apartment" name="apartment"
                                    placeholder="Apartment, suite, unit etc" value="<?php echo e(old('apartment')); ?>">
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="city">Town/City</label>
                                <input type="text" class="form-control" id="city" name="city" placeholder="Town/City"
                                    value="<?php echo e($user->city); ?>">
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="state">State</label>
                                <input type="text" class="form-control" id="state" name="state" placeholder="State"
                                    value="<?php echo e($user->state); ?>">
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="postcode">Postcode/Zip</label>
                                <input type="number" class="form-control" id="postcode" name="postcode"
                                    placeholder="Postcode / Zip" value="<?php echo e($user->postcode); ?>">
                            </div>
                            <div class="col-md-12">
                                <label for="order-notes">Order Notes</label>
                                <textarea class="form-control" id="order-notes" va name="note" cols="30" rows="10"
                                    placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                            </div>
                        </div>

                        <!-- Different Shipping Address -->
                        <div class="different-address mt-50">
                            <div class="mb-3 ship-different-title">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                    <label class="custom-control-label" for="customCheck1">Ship to a same
                                        address?</label>
                                </div>
                            </div>
                            <div class="row shipping_input_field">
                                <div class="mb-3 col-md-6">
                                    <label for="first_name">First Name</label>
                                    <input type="text" class="form-control" id="n_first_name" name="n_first_name"
                                        placeholder="First Name" value="<?php echo e($name[0]); ?>" required>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" class="form-control" id="n_last_name" name="n_last_name"
                                        placeholder="Last Name" value="<?php echo e($name[1]); ?>" required>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="email_address">Email Address</label>
                                    <input type="email" class="form-control" id="n_email" name="n_email"
                                        placeholder="Email Address" value="<?php echo e($user->email); ?>">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="phone_number">Phone Number</label>
                                    <input type="number" class="form-control" id="n_phone" name="n_phone" min="0"
                                        value="<?php echo e($user->phone); ?>" required>
                                </div>
                                <div class="mb-3 col-md-12">
                                    <label for="country">Country</label>
                                    <input type="text" class="form-control" id="n_country" name="n_country"
                                        value="<?php echo e($user->n_country); ?>" placeholder="ex. Sénégal">
                                </div>
                                <div class="mb-3 col-md-12">
                                    <label for="street_address">Street address</label>
                                    <input type="text" class="form-control" id="n_address" name="n_address"
                                        placeholder="Street Address" value="<?php echo e($user->n_address); ?>" required>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="apartment_suite">Apartment/Suite/Unit</label>
                                    <input type="text" class="form-control" id="n_apartment" name="n_apartment"
                                        placeholder="Apartment, suite, unit etc" value="<?php echo e(old('n_apartment')); ?>">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="city">Town/City</label>
                                    <input type="text" class="form-control" id="n_city" name="n_city"
                                        placeholder="Town/City" value="<?php echo e($user->n_city); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="state">State</label>
                                    <input type="text" class="form-control" id="n_state" name="n_state"
                                        placeholder="State" value="<?php echo e($user->n_state); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label for="postcode">Postcode/Zip</label>
                                    <input type="number" class="form-control" id="n_postcode" name="n_postcode"
                                        placeholder="Postcode / Zip" value="<?php echo e($user->n_postcode); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="sub_total" value="<?php echo e(Helper::currency_converter((float)str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->subtotal()))); ?>">
                <input type="hidden" name="total_amount" value="<?php echo e(Helper::currency_converter((float)str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->subtotal()))); ?>">
                
                <div class="col-12">
                    <div class="checkout_pagination d-flex justify-content-end mt-50">
                        <a href="<?php echo e(route('cart')); ?>" class="mt-2 ml-2 btn btn-primary">Go Back</a>
                        <button type="submit" class="mt-2 ml-2 btn btn-primary">Continue</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Checkout Area -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $('#customCheck1').on('change',function(e){
            e.preventDefault();
            if(this.checked){
                $('#n_first_name').val($('#first_name').val());
                $('#n_last_name').val($('#last_name').val());
                $('#n_email').val($('#email').val());
                $('#n_phone').val($('#phone').val());
                $('#n_country').val($('#country').val());
                $('#n_city').val($('#city').val());
                $('#n_postcode').val($('#postcode').val());
                $('#n_state').val($('#state').val());
                $('#n_address').val($('#address').val());
            }
            else{
                $('#n_first_name').val("");
                $('#n_last_name').val("");
                $('#n_email').val("");
                $('#n_phone').val("");
                $('#n_country').val("");
                $('#n_city').val("");
                $('#n_postcode').val("");
                $('#n_state').val("");
                $('#n_address').val("");
            }
        })
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/pages/checkout/checkout1.blade.php ENDPATH**/ ?>