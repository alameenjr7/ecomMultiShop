
        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-6">
                        <div class="welcome-note">
                            <span class="popover--text" data-toggle="popover" data-content="Welcome to Bigshop ecommerce template."><i class="icofont-info-square"></i></span>
                            <span class="text">Welcome to <?php echo e(get_setting('meta_keywords')); ?></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="language-currency-dropdown d-flex align-items-center justify-content-end">
                            <!-- Language Dropdown -->
                            <div class="language-dropdown">
                                <div class="dropdown">
                                    <a class="btn btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        English
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                                        <a class="dropdown-item" href="#">Francais</a>
                                        <a class="dropdown-item" href="#">Senegal</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Currency Dropdown -->
                            <div class="currency-dropdown">
                                <div class="dropdown">
                                    <?php
                                        Helper::currency_load();
                                        $currency_code=session('currency_code');
                                        $currency_symbol=session('currency_symbol');
                                        if($currency_symbol==""){
                                            $system_default_currency_info=session('system_default_currency_info');
                                            $currency_symbol=$system_default_currency_info->symbol;
                                            $currency_code=$system_default_currency_info->code;
                                        }
                                    ?>
                                    <a class="btn btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?php echo e($currency_symbol); ?> <?php echo e($currency_code); ?>

                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
                                        <?php $__currentLoopData = App\Models\Currency::where('status','active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="dropdown-item" href="javascript:;" onclick="currency_change('<?php echo e($currency['code']); ?>')"><?php echo e($currency->symbol); ?> <?php echo e(Illuminate\Support\Str::upper($currency->code)); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Menu -->
        <div class="bigshop-main-menu">
            <div class="container">
                <div class="classy-nav-container breakpoint-off">
                    <nav class="classy-navbar" id="bigshopNav">

                        <!-- Nav Brand -->
                        <a href="<?php echo e(route('home')); ?>" class="nav-brand"><img src="<?php echo e(asset(get_setting('logo'))); ?>" alt="logo"></a>

                        <!-- Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Close -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav -->
                            <div class="classynav">
                                <ul>
                                    <li class="active">
                                        <a href="<?php echo e(route('home')); ?>">Home</a>
                                    </li>
                                    <li><a href="<?php echo e(route('about.us')); ?>">About Us</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('shop')); ?>">Shop</a>
                                    </li>
                                    <li><a href="<?php echo e(route('blog.detail')); ?>">Blog</a>
                                    </li>
                                    
                                    <li><a href="<?php echo e(route('contact.us')); ?>">Contact</a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Hero Meta -->
                        <div class="ml-auto hero_meta_area d-flex align-items-center justify-content-end">
                            <!-- Search -->
                            <div class="search-area">
                                <div class="search-btn"><i class="icofont-search"></i></div>
                                <!-- Form -->
                                <form action="<?php echo e(route('search')); ?>" method="GET">
                                    <div class="search-form d-flex">
                                        <input type="search" id="search_text" name="query" class="form-control" placeholder="Search">
                                        <input type="submit" class="d-none" value="Send">
                                    </div>
                                </form>
                            </div>

                            <!-- Wishlist -->
                            <div class="cart-area">
                                <div class="cart--btn">
                                    <a href="<?php echo e(route('wishlist')); ?>">
                                        <i class="icofont-heart"></i>
                                        <span class="cart_quantity" id="wishlist_counter"><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::instance('wishlist')->count()); ?></span>
                                    </a>
                                </div>
                            </div>
                            <div class="cart-area">
                                <div class="cart--btn">
                                    <a href="<?php echo e(route('compare')); ?>" >
                                        <i class="icofont-exchange"></i>
                                        <span class="cart_quantity" id="compare_counter"><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::instance('compare')->count()); ?></span>
                                    </a>
                                </div>
                            </div>

                            <!-- Cart -->
                            <div class="cart-area">
                                <div class="cart--btn">
                                    <i class="icofont-cart"></i>
                                    <span class="cart_quantity"><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->count()); ?></span>
                                </div>

                                <!-- Cart Dropdown Content -->
                                <div class="cart-dropdown-content">
                                    <ul class="cart-list">
                                        <?php $__currentLoopData = \Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="cart-item-desc">
                                                    <a href="<?php echo e(route('user.dashboard')); ?>" class="image">
                                                        <img src="<?php echo e($item->model->photo); ?>" class="cart-thumb" alt="<?php echo e($item->model->photo); ?>">
                                                    </a>
                                                    <div>
                                                        <a href="<?php echo e(route('product.detail',$item->model->slug)); ?>"><?php echo e($item->name); ?></a>
                                                        <p><?php echo e($item->qty); ?> x - <span class="price"><?php echo e(Helper::currency_converter($item->price)); ?></span></p>
                                                    </div>
                                                </div>
                                                <span class="dropdown-product-remove cart_delete" data-id="<?php echo e($item->rowId); ?>"><i class="icofont-bin"></i></span>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="my-4 cart-pricing">
                                        <ul>
                                            <li>
                                                <span>Sub Total:</span>
                                                <span><?php echo e(Helper::currency_converter(\Gloudemans\Shoppingcart\Facades\Cart::subtotal())); ?></span>
                                            </li>
                                            
                                            <li>
                                                <span>Total:</span>
                                                <?php if(session()->has('coupon')): ?>
                                                    <span><?php echo e(Helper::currency_converter((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal())-\Illuminate\Support\Facades\Session::get('coupon')['value'])); ?></span>
                                                <?php else: ?>
                                                    <span><?php echo e(Helper::currency_converter(\Gloudemans\Shoppingcart\Facades\Cart::subtotal())); ?></span>
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="cart-box row-cols-2 d-flex">
                                        <a href="<?php echo e(route('cart')); ?>" class="btn-sm btn btn-success">Cart</a>
                                        <a href="<?php echo e(route('checkout1')); ?>" class="ml-1 btn-sm btn btn-primary">Checkout</a>
                                    </div>
                                </div>
                            </div>

                            <!-- Account -->
                            <div class="account-area">
                                <div class="user-thumbnail">
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if(auth()->user()->photo): ?>
                                            <img src="<?php echo e(auth()->user()->photo); ?>" alt="user photo">
                                        <?php else: ?>
                                            <img src="<?php echo e(Helper::userDefaultImage()); ?>" alt="default user image">
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <img src="<?php echo e(Helper::userDefaultImage()); ?>" alt="default user image">
                                    <?php endif; ?>
                                </div>
                                <ul class="user-meta-dropdown">
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php
                                            $first_name=explode(' ',auth()->user()->full_name);
                                        ?>
                                        <li class="user-title"><span>Hello,</span> <?php echo e($first_name[0]); ?> !</li>
                                        <li><a href="<?php echo e(route('user.dashboard')); ?>">My Account</a></li>
                                        <li><a href="<?php echo e(route('user.order')); ?>">Orders List</a></li>
                                        <li><a href="<?php echo e(route('wishlist')); ?>">Wishlist</a></li>
                                        <li><a href="<?php echo e(route('user.logout')); ?>"><i class="icofont-logout"></i> Logout</a></li>

                                    <?php else: ?>
                                        <li><a href="<?php echo e(route('user.auth')); ?>"><i class="fa fa-user"></i><span>  Login & Register</span></a></li>

                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    <!-- Header Area End -->
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>