<ul>
    <li class="<?php echo e(\Request::is('user/dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
    <li class="<?php echo e(\Request::is('user/order') ? 'active' : ''); ?>"><a href="<?php echo e(route('user.order')); ?>">Orders</a></li>
    <li class="<?php echo e(\Request::is('user/address') ? 'active' : ''); ?>"><a href="<?php echo e(route('user.address')); ?>">Addresses</a></li>
    <li class="<?php echo e(\Request::is('user/account-detail') ? 'active' : ''); ?>"><a href="<?php echo e(route('user.account')); ?>">Account Details</a></li>
    <li><a href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
</ul>
<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/user/sidebar.blade.php ENDPATH**/ ?>