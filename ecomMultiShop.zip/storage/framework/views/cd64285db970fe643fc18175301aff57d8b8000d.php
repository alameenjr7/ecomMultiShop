<div class="single-product-area mb-30">
    <div class="product_image">
        <!-- Product Image -->
        <?php
            $photo=explode(',',$product->photo)
        ?>
        <img class="normal_img" src="<?php echo e(asset($photo[0])); ?>" alt="<?php echo e($product->title); ?>">

        <!-- Product Badge -->
        <div class="product_badge">
            <span><?php echo e($product->conditions); ?></span>
            <?php if($product->discount>0): ?>
            <span class="mt-2"><?php echo e($product->discount); ?> %</span>
            <?php endif; ?>
        </div>

        <!-- Wishlist -->
        <div class="product_wishlist">
            <a href="javascript:void(0);" class="add_to_wishlist" data-quantity="1" data-id="<?php echo e($product->id); ?>"
                id="add_to_wishlist_<?php echo e($product->id); ?>"><i class="icofont-heart"></i></a>
        </div>

        <!-- Compare -->
        <div class="product_compare">
            <a href="javascript:void(0);" class="add_to_compare" data-id="<?php echo e($product->id); ?>" id="add_to_compare_<?php echo e($product->id); ?>"><i class="icofont-exchange"></i></a>
        </div>
    </div>

    <!-- Product Description -->
    <div class="product_description">
        <!-- Add to cart -->
        <div class="product_add_to_cart">
            <a href="javascript:void(0);" data-quantity="1" data-price="<?php echo e($product->offer_price); ?>" data-product-id="<?php echo e($product->id); ?>"
                class="add_to_cart" id="add_to_cart<?php echo e($product->id); ?>"><i class="icofont-shopping-cart"></i> Add to
                Cart</a>
        </div>

        <!-- Quick View -->
        <div class="product_quick_view">
            <a href="javascript:void(0);" data-target="#quickview<?php echo e($product->id); ?>" data-toggle="modal"><i class="icofont-eye-alt"></i>
                Quick View</a>
                
        </div>

        <p class="brand_name"><?php echo e(App\Models\Brand::where('id',$product->brand_id)->value('title')); ?></p>
        <a href="<?php echo e(route('product.detail', $product->slug)); ?>"><?php echo e(ucfirst($product->title)); ?></a>
        <?php if($product->discount>0): ?>
            <h6 class="product-price"><?php echo e(Helper::currency_converter($product->offer_price)); ?> <small><del
                class="text-danger"><?php echo e(Helper::currency_converter($product->price)); ?> </del></small></h6>
        <?php else: ?>
            <h6 class="product-price"><?php echo e(Helper::currency_converter($product->price)); ?></h6>
        <?php endif; ?>
    </div>
    <div class="container">
        <!-- Quick View Modal Area -->
        <?php echo $__env->make('frontend.unuses._modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<!-- Quick View Modal Area -->

<?php $__env->startSection('scripts'); ?>
<script>
    $('#quickview').modal('show').css(
        {
            'margin-top':function(){
                return -($(this).height()/2)
            },
            'margin-left':function(){
                return -($(this).width()/2)
            }
        }
    )
</script>
<?php $__env->stopSection(); ?>

<?php /**PATH C:\xampp\htdocs\laravel\ecomMultiShop\resources\views/frontend/layouts/_single-product.blade.php ENDPATH**/ ?>